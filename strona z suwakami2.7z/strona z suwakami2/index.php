<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div id="container">
        <div id="left">
            
         <div class="logo"><img src="obfdrovd1.png" alt=""></div>
         <h1>Dostępne filtry</h1>
<form>
    <label for="search"></label>
    <input type="text" id="search" placeholder=""><br><br>

    <select id="Miasto">
        <option value="">Miasto</option>
        <option value="warszawa">Warszawa</option>
        <option value="krakow">Kraków</option>
        <option value="wroclaw">Wrocław</option>
        <option value="lublin">Lublin</option>
        <option value="gdansk">Gdańsk</option>
        <option value="białystok">Białystok</option>
        <option value="szczecin">Szczecin</option>
    </select><br>

    <label for="cena">Cena za litr od:</label>
    <div><span id="minimum-price-value">1.00</span>zł</div>
    <input type="range" id="minimum-range" min="0" max="10" value="0">
    <span id="cena-value">0</span> zł<br><br>

    <label for="cena">Cena za litr do:</label>
    <div><span id="maximum-price-value">1.00</span>zł</div>
    <input type="range" id="maximum-rage" min="0" max="10" value="10">
    <span id="cena-value">10</span> zł<br><br>

    <input type="submit" value="Szukaj"/>
    <input type="reset" value="Wyczyść"/>
        </div>
    <div id="right">
        <div id="text">
           <h2> Wyniki awyszukiwania:</h2>
           <?php
           $conn = new mysqli("localhost","root","","stacje_paliw");

           $sql = "SELECT stacje_paliw.nazwa, stacje_paliw.cena, adresy.miasto, adresy.ulica, adresy.numer FROM stacje_paliw JOIN adresy ON stacje_paliw.adres = adresy.ID";
           
           $wynik = $conn->fetch_assoc()
           
           {
            echo 'div class="card flex-column gap-12 center-both">';
            echo '<h2>'. $stacja["nazwa"].'</h2>';
            echo '<div>';
            echo '<h3>cenapaliwa;</h3>';
            echo '<p>'.$stacja["cena_paliwa"].'zł'.'</p>';
            echo '</div>';
            echo '<div>';
            echo '<h3>adres;</h3>';
            echo '<p>'. $stacja["miasto"].'</p>';
            echo '<p>'. $stacja["ulica"].''.$stacja["numer"].'</p>';
            echo '<div>';
            echo '</div>';
           }

           $conn->close();
           ?>
        </div>

    </div>
    </div>
    <div id="tet" >
        Wyniki wyszukiwania:
    </div>
</form>
<script src="script.js"></script>
</body>
</html>